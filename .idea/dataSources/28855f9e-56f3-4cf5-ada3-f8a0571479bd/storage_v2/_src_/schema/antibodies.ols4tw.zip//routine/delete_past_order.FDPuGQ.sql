create procedure delete_past_order(IN `_id` int)
  BEGIN

    DELETE FROM antibodies.past_orders WHERE id = _id;
  end;

