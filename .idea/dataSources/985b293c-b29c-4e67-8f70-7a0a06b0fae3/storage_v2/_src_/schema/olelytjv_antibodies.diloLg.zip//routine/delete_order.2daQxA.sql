create procedure delete_order(IN `_id` int)
  BEGIN

    DELETE FROM orders WHERE id = _id;
  end;

