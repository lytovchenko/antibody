create procedure delete_order(IN `_id` int)
  BEGIN

    DELETE FROM olelytjv_antibodies.orders WHERE id = _id;
  end;

