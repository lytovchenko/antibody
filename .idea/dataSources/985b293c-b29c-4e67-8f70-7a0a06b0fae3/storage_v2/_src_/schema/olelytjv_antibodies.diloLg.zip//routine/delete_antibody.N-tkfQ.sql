create procedure delete_antibody(IN `_id` int)
  BEGIN

    DELETE FROM olelytjv_antibodies.list WHERE id = _id;
  end;

