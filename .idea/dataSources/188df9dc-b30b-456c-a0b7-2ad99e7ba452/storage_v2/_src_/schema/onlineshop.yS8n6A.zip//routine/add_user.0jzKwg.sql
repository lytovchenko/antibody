create procedure add_user(IN `_first_name` varchar(150), IN `_last_name` varchar(150), IN `_email` varchar(150),
                          IN `_login`      varchar(150), IN `_password` varchar(15))
  BEGIN

    INSERT INTO users (first_name, last_name, email, login, password, created, updated)
    VALUES (_first_name, _last_name, _email, _login, _password, now(), now());
  end;

