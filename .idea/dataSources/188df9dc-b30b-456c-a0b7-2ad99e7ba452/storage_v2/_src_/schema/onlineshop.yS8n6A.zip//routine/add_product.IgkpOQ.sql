create procedure add_product(IN code    varchar(15), IN name varchar(15), IN line varchar(15), IN scale varchar(10),
                             IN vendor  varchar(50), IN description text, IN quantity int(5), IN price decimal(10, 2),
                             IN `_MSRP` decimal(10, 2))
  BEGIN

    INSERT INTO products (productCode,
                          productName,
                          productLine,
                          productScale,
                          productVendor,
                          productDescription,
                          quantityInStock,
                          buyPrice,
                          MSRP)
    VALUES (code, name, line, scale, vendor, description, quantity, price, _MSRP);
  end;

