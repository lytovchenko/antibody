create procedure get_product_by_ID(IN  id         varchar(15), OUT name varchar(100), OUT line varchar(50),
                                   OUT scale      varchar(10), OUT vendor varchar(50), OUT description text,
                                   OUT quantity   int(5), OUT price decimal(10, 2), OUT `_MSRP` decimal(10, 2),
                                   OUT `_created` timestamp, OUT `_updated` timestamp)
  BEGIN

    SELECT productName INTO name FROM products WHERE productCode = id;
    SELECT productLine INTO line FROM products WHERE productCode = id;
    SELECT productScale INTO scale FROM products WHERE productCode = id;
    SELECT productVendor INTO vendor FROM products WHERE productCode = id;
    SELECT productDescription INTO description FROM products WHERE productCode = id;
    SELECT quantityInStock INTO quantity FROM products WHERE productCode = id;
    SELECT buyPrice INTO price FROM products WHERE productCode = id;
    SELECT MSRP INTO _MSRP FROM products WHERE productCode = id;
    SELECT created INTO _created FROM products WHERE productCode = id;
    SELECT updated INTO _updated FROM products WHERE productCode = id;


  end;

