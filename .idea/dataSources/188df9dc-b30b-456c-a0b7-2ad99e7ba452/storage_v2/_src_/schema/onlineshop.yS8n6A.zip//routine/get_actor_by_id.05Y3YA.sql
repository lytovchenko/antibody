create procedure get_actor_by_ID(IN  id         smallint, OUT firstName varchar(45), OUT lastName varchar(45),
                                 OUT lastUpdate timestamp)
  BEGIN

    SELECT first_name INTO firstName FROM actor WHERE actor_id = id;
    SELECT last_name INTO lastName FROM actor WHERE actor_id = id;
    SELECT last_update INTO lastUpdate FROM actor WHERE actor_id = id;
    
    
  end;

