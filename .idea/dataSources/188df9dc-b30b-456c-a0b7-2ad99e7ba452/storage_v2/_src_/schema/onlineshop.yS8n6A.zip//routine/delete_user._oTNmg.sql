create procedure delete_user(IN `_id` int)
  BEGIN

    DELETE FROM onlineShop.users WHERE id=_id;
  end;

