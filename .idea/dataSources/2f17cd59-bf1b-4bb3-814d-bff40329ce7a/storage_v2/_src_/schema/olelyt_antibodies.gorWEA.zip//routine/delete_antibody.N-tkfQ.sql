create procedure delete_antibody(IN `_id` int)
  BEGIN

    DELETE FROM antibodies.list WHERE id = _id;
  end;

