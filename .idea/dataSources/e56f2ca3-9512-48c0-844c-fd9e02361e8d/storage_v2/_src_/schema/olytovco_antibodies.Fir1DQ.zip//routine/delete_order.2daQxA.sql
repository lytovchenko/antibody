create procedure delete_order(IN `_id` int)
  BEGIN

    DELETE FROM olytovco_antibodies.orders WHERE id = _id;
  end;

